"""
SID Query Assistant - Backend Server
Run with: pip install fastapi uvicorn httpx python-multipart && python server.py
"""

from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import httpx
import json

app = FastAPI(title="SID Query Assistant")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Models ───────────────────────────────────────────────

class QueryRequest(BaseModel):
    question: str
    schema_context: str
    endpoint: str
    api_key: str
    deployment: str = "gpt-4o"

# ── Schema Upload ─────────────────────────────────────────

@app.post("/api/parse-schema")
async def parse_schema(file: UploadFile = File(...)):
    """
    Accept the columns JSON exported from SID.
    Supports both:
      - Plain array: [{table_schema, table_name, column_name, data_type, is_nullable}, ...]
      - Object with one key containing the array (as seen in the hackathon file)
    """
    try:
        raw = await file.read()
        data = json.loads(raw)

        # If wrapped in an object, grab first list value
        if isinstance(data, dict):
            for v in data.values():
                if isinstance(v, list):
                    data = v
                    break

        if not isinstance(data, list):
            raise HTTPException(status_code=400, detail="JSON must be an array of column objects.")

        # Group columns by schema.table
        tables: dict = {}
        for row in data:
            schema  = row.get("table_schema", "public")
            tname   = row.get("table_name", "")
            cname   = row.get("column_name", "")
            dtype   = row.get("data_type", "")
            nullable = row.get("is_nullable", "YES")

            key = f"{schema}.{tname}"
            if key not in tables:
                tables[key] = {"schema": schema, "table": tname, "columns": []}
            tables[key]["columns"].append({
                "name": cname,
                "type": dtype,
                "nullable": nullable == "YES"
            })

        # Build DDL string for the AI prompt
        ddl_lines = []
        for key, t in sorted(tables.items()):
            cols = ",\n  ".join(
                f"{c['name']} {c['type']}{'' if c['nullable'] else ' NOT NULL'}"
                for c in t["columns"]
            )
            ddl_lines.append(
                f"-- schema: {t['schema']}\nCREATE TABLE {t['schema']}.{t['table']} (\n  {cols}\n);"
            )

        schema_sql = "\n\n".join(ddl_lines)

        return {
            "tables": list(tables.values()),
            "schema_sql": schema_sql,
            "table_count": len(tables),
            "column_count": len(data)
        }

    except json.JSONDecodeError as e:
        raise HTTPException(status_code=400, detail=f"Invalid JSON: {e}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── SQL Generation ────────────────────────────────────────

SYSTEM_PROMPT = """You are a SQL expert for the SID (Securities Information Database) at SIX Swiss Exchange, Switzerland.

Your job:
1. Read the database schema provided (schemas, table names, columns, data types)
2. Generate a correct, optimized PostgreSQL SELECT query for the user's question
3. Write a 1-2 sentence plain English explanation of what the query does

Rules:
- ONLY generate SELECT queries. Never INSERT, UPDATE, DELETE, DROP, or any DDL.
- Always use schema-qualified table names (e.g. corporateaction.agm)
- Use table aliases for readability
- Add proper WHERE, JOIN, ORDER BY, LIMIT clauses as needed
- Always qualify ambiguous column names with table aliases
- Use ILIKE for case-insensitive text search

Respond ONLY in this exact JSON format (no markdown fences, no preamble):
{"sql": "SELECT ...", "explanation": "This query..."}"""

@app.post("/api/generate-sql")
async def generate_sql(req: QueryRequest):
    endpoint = req.endpoint.rstrip("/")
    if "/chat/completions" not in endpoint:
        endpoint = f"{endpoint}/openai/deployments/{req.deployment}/chat/completions?api-version=2024-02-01"

    payload = {
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"Database schema:\n{req.schema_context}\n\nQuestion: {req.question}"}
        ],
        "max_completion_tokens": 1000,
        "temperature": 0.1
    }

    headers = {"Content-Type": "application/json", "api-key": req.api_key}

    async with httpx.AsyncClient(timeout=40) as client:
        try:
            resp = await client.post(endpoint, json=payload, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            content = data["choices"][0]["message"]["content"]
            content = content.replace("```json", "").replace("```", "").strip()
            parsed = json.loads(content)
            return {"sql": parsed.get("sql", ""), "explanation": parsed.get("explanation", "")}
        except httpx.HTTPStatusError as e:
            raise HTTPException(status_code=e.response.status_code, detail=f"OpenAI error: {e.response.text}")
        except json.JSONDecodeError:
            raise HTTPException(status_code=500, detail="Could not parse model response as JSON")
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))


# ── Serve frontend ────────────────────────────────────────

app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
async def root():
    return FileResponse("static/index.html")

if __name__ == "__main__":
    import uvicorn
    print("\n SID Query Assistant → http://localhost:8000\n")
    uvicorn.run("server:app", host="0.0.0.0", port=8000, reload=True)
