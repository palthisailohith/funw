"""
SID Query Assistant - Backend Server
Run with: pip install fastapi uvicorn httpx psycopg2-binary python-dotenv && python server.py
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import httpx
import json
import os
from typing import Optional, Any

app = FastAPI(title="SID Query Assistant")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Models ──────────────────────────────────────────────

class OpenAIConfig(BaseModel):
    endpoint: str
    api_key: str
    deployment: str = "gpt-4o"

class DBConfig(BaseModel):
    host: str
    port: int = 5432
    database: str
    username: str
    password: str
    db_type: str = "postgresql"   # postgresql | mssql | oracle

class QueryRequest(BaseModel):
    question: str
    schema_context: str
    openai: OpenAIConfig

class ExecuteRequest(BaseModel):
    sql: str
    db: DBConfig

class TestDBRequest(BaseModel):
    db: DBConfig

# ── OpenAI Proxy ─────────────────────────────────────────

SYSTEM_PROMPT = """You are a SQL expert for the SID (Securities Information Database) at SIX Swiss Exchange, Switzerland.

Your job:
1. Read the database schema provided
2. Generate a correct, optimized SQL SELECT query for the user's question
3. Write a 1-2 sentence plain English explanation of what the query does

Rules:
- ONLY generate SELECT queries. Never INSERT, UPDATE, DELETE, DROP, or DDL.
- Use table aliases for readability
- Add proper WHERE, JOIN, ORDER BY, LIMIT clauses as needed
- Use appropriate date functions for the database type
- Always qualify ambiguous column names with table aliases

Respond ONLY in this exact JSON (no markdown, no backticks, no preamble):
{"sql": "SELECT ...", "explanation": "This query..."}"""

@app.post("/api/generate-sql")
async def generate_sql(req: QueryRequest):
    # Build the Azure OpenAI URL
    # If user gave the full URL use it, otherwise build it
    endpoint = req.openai.endpoint.rstrip("/")
    if "/chat/completions" not in endpoint:
        endpoint = f"{endpoint}/openai/deployments/{req.openai.deployment}/chat/completions?api-version=2024-02-01"

    payload = {
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"Database schema:\n{req.schema_context}\n\nQuestion: {req.question}"}
        ],
        "max_tokens": 1000,
        "temperature": 0.1
    }

    headers = {
        "Content-Type": "application/json",
        "api-key": req.openai.api_key
    }

    async with httpx.AsyncClient(timeout=30) as client:
        try:
            resp = await client.post(endpoint, json=payload, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            content = data["choices"][0]["message"]["content"]
            # strip markdown fences if model adds them
            content = content.replace("```json", "").replace("```", "").strip()
            parsed = json.loads(content)
            return {"sql": parsed.get("sql", ""), "explanation": parsed.get("explanation", "")}
        except httpx.HTTPStatusError as e:
            raise HTTPException(status_code=e.response.status_code, detail=f"OpenAI API error: {e.response.text}")
        except json.JSONDecodeError:
            raise HTTPException(status_code=500, detail="Could not parse model response as JSON")
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))


# ── Database Execution ───────────────────────────────────

def get_connection(cfg: DBConfig):
    """Get a DB connection based on type"""
    if cfg.db_type == "postgresql":
        import psycopg2
        import psycopg2.extras
        conn = psycopg2.connect(
            host=cfg.host,
            port=cfg.port,
            dbname=cfg.database,
            user=cfg.username,
            password=cfg.password,
            connect_timeout=10
        )
        return conn, "psycopg2"
    elif cfg.db_type == "mssql":
        import pyodbc
        conn_str = (
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={cfg.host},{cfg.port};"
            f"DATABASE={cfg.database};"
            f"UID={cfg.username};"
            f"PWD={cfg.password};"
            f"Connection Timeout=10;"
        )
        conn = pyodbc.connect(conn_str)
        return conn, "pyodbc"
    elif cfg.db_type == "oracle":
        import cx_Oracle
        dsn = cx_Oracle.makedsn(cfg.host, cfg.port, service_name=cfg.database)
        conn = cx_Oracle.connect(user=cfg.username, password=cfg.password, dsn=dsn)
        return conn, "cx_oracle"
    else:
        raise ValueError(f"Unsupported db_type: {cfg.db_type}")


@app.post("/api/test-connection")
async def test_connection(req: TestDBRequest):
    try:
        conn, driver = get_connection(req.db)
        cur = conn.cursor()
        if req.db.db_type == "postgresql":
            cur.execute("SELECT version()")
            version = cur.fetchone()[0]
        elif req.db.db_type == "mssql":
            cur.execute("SELECT @@VERSION")
            version = cur.fetchone()[0]
        else:
            cur.execute("SELECT * FROM v$version WHERE banner LIKE 'Oracle%'")
            version = cur.fetchone()[0]
        cur.close()
        conn.close()
        return {"success": True, "version": version}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/execute")
async def execute_query(req: ExecuteRequest):
    # Safety: only allow SELECT
    sql_stripped = req.sql.strip().upper()
    if not sql_stripped.startswith("SELECT") and not sql_stripped.startswith("WITH"):
        raise HTTPException(status_code=400, detail="Only SELECT queries are allowed for safety.")

    try:
        conn, driver = get_connection(req.db)
        cur = conn.cursor()
        cur.execute(req.sql)
        rows = cur.fetchmany(200)  # limit to 200 rows in UI
        if cur.description:
            columns = [desc[0] for desc in cur.description]
        else:
            columns = []
        # Serialize rows (handle dates, decimals, etc.)
        serialized = []
        for row in rows:
            serialized.append([str(v) if v is not None else None for v in row])
        total = cur.rowcount if cur.rowcount >= 0 else len(serialized)
        cur.close()
        conn.close()
        return {"columns": columns, "rows": serialized, "count": len(serialized), "total": total}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/api/schema-tables")
async def get_schema_tables(host: str, port: int, database: str, username: str, password: str, db_type: str = "postgresql"):
    """Introspect the actual DB schema"""
    cfg = DBConfig(host=host, port=port, database=database, username=username, password=password, db_type=db_type)
    try:
        conn, driver = get_connection(cfg)
        cur = conn.cursor()
        if db_type == "postgresql":
            cur.execute("""
                SELECT t.table_name, c.column_name, c.data_type
                FROM information_schema.tables t
                JOIN information_schema.columns c ON t.table_name = c.table_name
                WHERE t.table_schema = 'public' AND t.table_type = 'BASE TABLE'
                ORDER BY t.table_name, c.ordinal_position
            """)
        elif db_type == "mssql":
            cur.execute("""
                SELECT t.name as table_name, c.name as column_name, ty.name as data_type
                FROM sys.tables t
                JOIN sys.columns c ON t.object_id = c.object_id
                JOIN sys.types ty ON c.user_type_id = ty.user_type_id
                ORDER BY t.name, c.column_id
            """)
        rows = cur.fetchall()
        cur.close()
        conn.close()
        # Build structured schema
        tables = {}
        for row in rows:
            tname, cname, dtype = row[0], row[1], row[2]
            if tname not in tables:
                tables[tname] = []
            tables[tname].append({"name": cname, "type": dtype})
        return {"tables": tables}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ── Serve frontend ───────────────────────────────────────

app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
async def root():
    return FileResponse("static/index.html")


if __name__ == "__main__":
    import uvicorn
    print("\n🚀 SID Query Assistant running at http://localhost:8000\n")
    uvicorn.run("server:app", host="0.0.0.0", port=8000, reload=True)
