"""
SID Query Assistant - Conversational + DB Execution Backend
pip install fastapi uvicorn httpx python-multipart psycopg2-binary && python server.py
For MSSQL: pip install pyodbc
For Oracle: pip install cx_Oracle
"""

from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import List, Optional
import httpx
import json

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ── Models ────────────────────────────────────────────────

class Message(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    messages: List[Message]
    schema_context: str
    endpoint: str
    api_key: str
    deployment: str = "gpt-4o"

class DBConfig(BaseModel):
    host: str
    port: int = 5432
    database: str
    username: str
    password: str
    db_type: str = "postgresql"  # postgresql | mssql | oracle

class ExecuteRequest(BaseModel):
    sql: str
    db: DBConfig

class TestDBRequest(BaseModel):
    db: DBConfig

# ── Schema Upload ─────────────────────────────────────────

@app.post("/api/parse-schema")
async def parse_schema(file: UploadFile = File(...)):
    try:
        raw = await file.read()
        data = json.loads(raw)
        if isinstance(data, dict):
            for v in data.values():
                if isinstance(v, list):
                    data = v
                    break
        if not isinstance(data, list):
            raise HTTPException(status_code=400, detail="JSON must be an array of column objects.")

        tables: dict = {}
        for row in data:
            schema   = row.get("table_schema", "public")
            tname    = row.get("table_name", "")
            cname    = row.get("column_name", "")
            dtype    = row.get("data_type", "")
            nullable = row.get("is_nullable", "YES")
            key = f"{schema}.{tname}"
            if key not in tables:
                tables[key] = {"schema": schema, "table": tname, "columns": []}
            tables[key]["columns"].append({"name": cname, "type": dtype, "nullable": nullable == "YES"})

        ddl_lines = []
        for key, t in sorted(tables.items()):
            cols = ",\n  ".join(
                f"{c['name']} {c['type']}{'' if c['nullable'] else ' NOT NULL'}"
                for c in t["columns"]
            )
            ddl_lines.append(f"-- schema: {t['schema']}\nCREATE TABLE {t['schema']}.{t['table']} (\n  {cols}\n);")

        return {
            "tables": list(tables.values()),
            "schema_sql": "\n\n".join(ddl_lines),
            "table_count": len(tables),
            "column_count": len(data)
        }
    except json.JSONDecodeError as e:
        raise HTTPException(status_code=400, detail=f"Invalid JSON: {e}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ── Conversational Chat ───────────────────────────────────

SYSTEM_PROMPT = """You are SID Assistant — a helpful, conversational AI analyst for the SID (Securities Information Database) at SIX Swiss Exchange, Switzerland.

You have been given the full database schema. You can:
- Generate SQL queries when the user asks for data
- Explain queries you've already written
- Answer follow-up questions about results, columns, or logic
- Have natural conversation about the data, schema, or database design
- Help debug or improve queries
- Explain what tables and columns mean in a financial/securities context

When generating SQL:
- Always use schema-qualified table names (e.g. corporateaction.agm)
- Only write SELECT queries — never INSERT, UPDATE, DELETE, or DDL
- Wrap SQL in triple backticks with sql tag: ```sql ... ```
- After the SQL, add a short plain-English explanation

When NOT generating SQL (follow-ups, explanations, general chat):
- Respond naturally and conversationally
- Reference column/table names in backticks when relevant

You maintain full context — remember every query and answer in the conversation.

Database schema:
{SCHEMA}"""

@app.post("/api/chat")
async def chat(req: ChatRequest):
    endpoint = req.endpoint.rstrip("/")
    if "/chat/completions" not in endpoint:
        endpoint = f"{endpoint}/openai/deployments/{req.deployment}/chat/completions?api-version=2024-02-01"

    system = SYSTEM_PROMPT.replace("{SCHEMA}", req.schema_context or "-- No schema loaded yet")
    messages = [{"role": "system", "content": system}]
    for m in req.messages:
        messages.append({"role": m.role, "content": m.content})

    payload = {"messages": messages, "max_completion_tokens": 1500, "temperature": 0.4}
    headers = {"Content-Type": "application/json", "api-key": req.api_key}

    async with httpx.AsyncClient(timeout=60) as client:
        try:
            resp = await client.post(endpoint, json=payload, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            return {"reply": data["choices"][0]["message"]["content"]}
        except httpx.HTTPStatusError as e:
            raise HTTPException(status_code=e.response.status_code, detail=f"OpenAI error: {e.response.text}")
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

# ── Database Connection ───────────────────────────────────

def get_connection(cfg: DBConfig):
    if cfg.db_type == "postgresql":
        import psycopg2
        conn = psycopg2.connect(
            host=cfg.host, port=cfg.port, dbname=cfg.database,
            user=cfg.username, password=cfg.password, connect_timeout=10
        )
        return conn
    elif cfg.db_type == "mssql":
        import pyodbc
        conn_str = (
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={cfg.host},{cfg.port};DATABASE={cfg.database};"
            f"UID={cfg.username};PWD={cfg.password};Connection Timeout=10;"
        )
        return pyodbc.connect(conn_str)
    elif cfg.db_type == "oracle":
        import cx_Oracle
        dsn = cx_Oracle.makedsn(cfg.host, cfg.port, service_name=cfg.database)
        return cx_Oracle.connect(user=cfg.username, password=cfg.password, dsn=dsn)
    else:
        raise ValueError(f"Unsupported db_type: {cfg.db_type}")

@app.post("/api/test-connection")
async def test_connection(req: TestDBRequest):
    try:
        conn = get_connection(req.db)
        cur = conn.cursor()
        if req.db.db_type == "postgresql":
            cur.execute("SELECT version()")
        elif req.db.db_type == "mssql":
            cur.execute("SELECT @@VERSION")
        else:
            cur.execute("SELECT * FROM v$version WHERE ROWNUM=1")
        version = str(cur.fetchone()[0])[:120]
        cur.close(); conn.close()
        return {"success": True, "version": version}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/execute")
async def execute_query(req: ExecuteRequest):
    sql_upper = req.sql.strip().upper()
    if not (sql_upper.startswith("SELECT") or sql_upper.startswith("WITH")):
        raise HTTPException(status_code=400, detail="Only SELECT queries are allowed.")
    try:
        conn = get_connection(req.db)
        cur = conn.cursor()
        cur.execute(req.sql)
        rows = cur.fetchmany(500)
        columns = [desc[0] for desc in cur.description] if cur.description else []
        serialized = [[str(v) if v is not None else None for v in row] for row in rows]
        cur.close(); conn.close()
        return {"columns": columns, "rows": serialized, "count": len(serialized)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# ── Static ────────────────────────────────────────────────

app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
async def root():
    return FileResponse("static/index.html")

if __name__ == "__main__":
    import uvicorn
    print("\n  SID Assistant → http://localhost:8000\n")
    uvicorn.run("server:app", host="0.0.0.0", port=8000, reload=True)
