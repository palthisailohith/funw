# SID Query Assistant
**Natural Language → SQL for SIX Swiss Exchange SID Database**

---

## Setup

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

For **SQL Server (MSSQL)** also install:
```bash
pip install pyodbc
# + install "ODBC Driver 17 for SQL Server" from Microsoft
```

For **Oracle** also install:
```bash
pip install cx_Oracle
# + Oracle Instant Client
```

### 2. Run the server
```bash
python server.py
```

Open **http://localhost:8000** in your browser.

---

## Configuration (in the UI)

### Azure OpenAI
Click **"Azure OpenAI"** in the top bar and fill in:
- **Endpoint URL** — full URL e.g. `https://your-resource.openai.azure.com/openai/deployments/gpt-4o/chat/completions?api-version=2024-02-01`
- **API Key** — your Azure OpenAI key
- **Deployment name** — e.g. `gpt-4o`

### SID Database
Click **"Database"** in the top bar and fill in:
- **Type** — PostgreSQL / SQL Server / Oracle
- **Host, Port, Database, Username, Password**

Click **"Test connection"** to verify, then **"Save & connect"**.

---

## Features
- Natural language → SQL generation via Azure OpenAI GPT-4o
- Live schema introspection from your real SID database
- Query execution with results shown in-app
- CSV export of results
- Query history (stored locally)
- Copy SQL to clipboard
- Read-only safety (SELECT only)

---

## Security Notes
- Credentials are stored in browser `localStorage` — do not use on shared machines
- Only `SELECT` and `WITH` queries are allowed to execute — no writes
- For production, add authentication middleware to `server.py`
